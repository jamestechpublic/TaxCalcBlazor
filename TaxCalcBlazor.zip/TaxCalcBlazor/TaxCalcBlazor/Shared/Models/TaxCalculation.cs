﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxCalcBlazor.Shared.Models
{
    public class TaxCalculation
    {
        public int Id { get; set; }
        public DateTime CalcDateTime { get; set; }
        public string PostalCode { get; set; } = string.Empty;
        public decimal IncomeAmount { get; set; }
        public decimal TaxAmount { get; set; }
    }
}
