﻿namespace TaxCalcBlazor.Server.AppLogic
{
	public enum TaxTypes { FlatValue, FlatRate, Progressive }; 

	public class TaxCalc
	{
		public List<PostalCodeTaxType> PostalCodeTax = new List<PostalCodeTaxType>();

		List<TaxBracket> _taxBrackets = new List<TaxBracket>();
		
		public TaxCalc()
		{
			Setup_PostalCodes();
			Setup_TaxBrackets();
		}

		private void Setup_PostalCodes()
		{
			PostalCodeTax.Add(new PostalCodeTaxType() { PostalCode = "7441", TaxType = TaxTypes.Progressive });
            PostalCodeTax.Add(new PostalCodeTaxType() { PostalCode = "A001", TaxType = TaxTypes.FlatValue });
            PostalCodeTax.Add(new PostalCodeTaxType() { PostalCode = "7000", TaxType = TaxTypes.FlatRate });
            PostalCodeTax.Add(new PostalCodeTaxType() { PostalCode = "1000", TaxType = TaxTypes.Progressive });
        }

		private void Setup_TaxBrackets()
		{
			_taxBrackets.Add(new TaxBracket() { Rate = 0.1m, From = 0, To = 8350 });
			_taxBrackets.Add(new TaxBracket() { Rate = 0.15m, From = 8351, To = 33950 });
			_taxBrackets.Add(new TaxBracket() { Rate = 0.25m, From = 33951, To = 82250 });
			_taxBrackets.Add(new TaxBracket() { Rate = 0.28m, From = 82251, To = 171550 });
			_taxBrackets.Add(new TaxBracket() { Rate = 0.33m, From = 171551, To = 372950 });
			_taxBrackets.Add(new TaxBracket() { Rate = 0.35m, From = 372951, To = decimal.MaxValue });
		}

		public decimal CalcPostalCodeTax(string postalCode, decimal income)
		{
			decimal tax = 0;

			if (income <= 0) return 0;

			PostalCodeTaxType? pctax = PostalCodeTax.Find(p => p.PostalCode.ToUpper() == postalCode.ToUpper());
			if (pctax == null) return 0;


			switch (pctax.TaxType)
			{
				case TaxTypes.FlatValue:
					tax = CalcFlatValue(income);
					break;
				case TaxTypes.FlatRate:
					tax = CalcFlatRate(income);
					break;
				case TaxTypes.Progressive:
					tax = CalcProgressive(income);
					break;
				default:
					tax = 0;
					break;
			}

			return tax;
		}

		/// <summary>
		///		If income is less than 200000 apply 5% tax rate
		///		else tax amount is 10000
		/// </summary>
		/// <param name="income">Income value to calculate tax on</param>
		/// <returns>Tax amount</returns>
		public decimal CalcFlatValue(decimal income)
		{
			if (income < 200000) return income * 0.05m;
			else return 10000m;
		}

		/// <summary>
		///		Apply flat tax rate to entire income value
		/// </summary>
		/// <param name="income">Income value to calculate tax on</param>
		/// <returns>Tax amount</returns>
		public decimal CalcFlatRate(decimal income)
		{
			return income * 0.175m;
		}

		/// <summary>
		///		From the top tax bracket...
		///		Calculate the top taxable portion
		///		Apply the tax rate for the taxable portion
		///		Reduce the income to the next lower tax bracket
		///		Repeat for all tax brackets except last which is applaied to remaining income
		/// </summary>
		/// <param name="income">Income value to calculate tax on</param>
		/// <returns>Tax Amount</returns>
		public decimal CalcProgressive(decimal income)
		{
			decimal tax = 0;
			for (int i = _taxBrackets.Count - 1; i > 0; i--) 
			{
				if (income >= _taxBrackets[i].From)
				{
					decimal taxable = income - _taxBrackets[i-1].To;
					tax += taxable * _taxBrackets[i].Rate;
					income = _taxBrackets[i-1].To;
				}
			}
			tax += income * _taxBrackets[0].Rate;

			return tax;
		}
	}

	public class TaxBracket
	{
		public decimal Rate { get; set; }
		public decimal From { get; set; }
		public decimal To { get; set; }
	}

	public class PostalCodeTaxType
	{
		public string PostalCode { get; set; } = string.Empty;
		public TaxTypes TaxType { get; set; }
	}
}
