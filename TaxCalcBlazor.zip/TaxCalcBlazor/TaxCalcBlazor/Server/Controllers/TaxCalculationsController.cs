﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.InteropServices;
using TaxCalcBlazor.Server.AppLogic;
using TaxCalcBlazor.Shared.Models;

namespace TaxCalcBlazor.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaxCalculationsController : ControllerBase
    {
        private readonly DataContext _context;

        public TaxCalculationsController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<TaxCalculation>>> GetAllTaxCalculationsAsync()
        {
            var result = await _context.TaxCalculations.ToListAsync();

            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TaxCalculation>> GetSingleTaxCalculationAsync(int id)
        {
            var result = await _context.TaxCalculations.FirstOrDefaultAsync(t => t.Id == id);

            if (result == null) return NotFound($"No tax calculation with id {id} found.");

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<List<TaxCalculation>>> CreateTaxCaculationAsync(TaxCalculation taxCalculation)
        {
            taxCalculation.CalcDateTime = DateTime.Now;
			AppLogic.TaxCalc tc = new AppLogic.TaxCalc();
			taxCalculation.TaxAmount = tc.CalcPostalCodeTax(taxCalculation.PostalCode, taxCalculation.IncomeAmount);

			_context.TaxCalculations.Add(taxCalculation);
			await _context.SaveChangesAsync();

            return Ok(await GetDbTaxCalculations());
        }

        [HttpPut]
        public async Task<ActionResult<List<TaxCalculation>>> UpdateTaxCalculation(TaxCalculation taxCalculation)
        {
            var taxCalc = await _context.TaxCalculations.FirstOrDefaultAsync(t => t.Id == taxCalculation.Id);

            if (taxCalc == null) return NotFound($"Tax calculation with id {taxCalculation.Id} not found");

            taxCalc.CalcDateTime = DateTime.Now;
            taxCalc.PostalCode = taxCalculation.PostalCode;
            taxCalc.IncomeAmount = taxCalculation.IncomeAmount;
            AppLogic.TaxCalc tc = new AppLogic.TaxCalc();
            taxCalc.TaxAmount = tc.CalcPostalCodeTax(taxCalc.PostalCode, taxCalc.IncomeAmount);

            await _context.SaveChangesAsync();

            return Ok(await GetDbTaxCalculations());
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<List<TaxCalculation>>> DeleteTaxCalculation(int id)
        {
            var taxCalc = await _context.TaxCalculations.FirstOrDefaultAsync(t => t.Id == id);
            if (taxCalc == null) return NotFound($"Tax calculation with id {id} not found");

            _context.Remove(taxCalc);
            await _context.SaveChangesAsync();

			return Ok(await GetDbTaxCalculations());
		}

        [HttpGet("calculatetax/{postalCode}/{income}")]
        public async Task<ActionResult<decimal>> CalculateTax(string postalCode, decimal income)
        {
            AppLogic.TaxCalc taxCalc = new AppLogic.TaxCalc();
            decimal taxAmount = taxCalc.CalcPostalCodeTax(postalCode, income);

            return Ok(taxAmount);
        }

        [HttpGet("getpostalcodes")]
        public async Task<ActionResult<List<string>>> GetPostalCodes()
        {
            List<string> result = new List<string>();
            AppLogic.TaxCalc taxCalc = new AppLogic.TaxCalc();
            foreach (AppLogic.PostalCodeTaxType pt in taxCalc.PostalCodeTax)
            {
                result.Add(pt.PostalCode);
            }
            return Ok(result);
        }

        private async Task<List<TaxCalculation>> GetDbTaxCalculations()
        {
            return await _context.TaxCalculations.ToListAsync();
        }

    }
}
