﻿using Microsoft.AspNetCore.Components;
using System.Net.Http.Json;
using TaxCalcBlazor.Shared.Models;

namespace TaxCalcBlazor.Client.Services
{
    public class TaxCalcServices : ITaxCalcServices
    {
        private readonly HttpClient _http;
        private readonly NavigationManager _navigationManager;

        public TaxCalcServices(HttpClient http, NavigationManager navigationManager)
        {
            _http = http;
            _navigationManager = navigationManager;
        }

		public List<TaxCalculation> TaxCalculations { get; set; } = new List<TaxCalculation>();
        public List<string> PostalCodes { get; set; } = new List<string>();

		public async Task GetAllTaxCalculationsAsync()
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<TaxCalculation>>("api/taxcalculations");

                if (result != null) TaxCalculations = result;
                else TaxCalculations = new List<TaxCalculation>();
            }
            catch
            {
                TaxCalculations = new List<TaxCalculation>();
            }
        }

        public async Task<TaxCalculation> GetSingleTaxCalculationsAsync(int id)
        {
            try
            {
                var result = await _http.GetFromJsonAsync<TaxCalculation>($"api/TaxCalculations/{id}");

                if (result != null) return result;
                else return new TaxCalculation();
            }
            catch
            {
                return new TaxCalculation();
            }
        }

        public async Task CreateTaxCalculationAsync(TaxCalculation taxCalculation)
        {
            try
            {
                var result = await _http.PostAsJsonAsync("api/TaxCalculations", taxCalculation);

                SetTaxCalculations(result);
            }
            catch
            {
				TaxCalculations = new List<TaxCalculation>();
			}
        }

		public async Task UpdateTaxCalculationAsync(TaxCalculation taxCalculation)
		{
			try
			{
				var result = await _http.PutAsJsonAsync("api/TaxCalculations", taxCalculation);

                SetTaxCalculations(result);
			}
			catch
			{
				TaxCalculations = new List<TaxCalculation>();
			}
		}

		public async Task DeleteTaxCalculationAsync(int id)
		{
			try
			{
				var result = await _http.DeleteAsync($"api/TaxCalculations/{id}");

                SetTaxCalculations(result);
			}
			catch
			{
				TaxCalculations = new List<TaxCalculation>();
			}
		}

		public async Task<TaxCalculation> CalculateTaxAsync(TaxCalculation taxCalculation)
		{
            try
            {
                decimal taxAmount = await _http.GetFromJsonAsync<decimal>($"api/TaxCalculations/calculatetax/{taxCalculation.PostalCode}/{taxCalculation.IncomeAmount}");
                taxCalculation.TaxAmount = taxAmount;
                return taxCalculation;
            }
            catch
            {
                taxCalculation.TaxAmount = 0.0m;
                return taxCalculation;
            }

		}

		public async Task GetPostalCodes()
		{
            try
            {
                List<string>? result = await _http.GetFromJsonAsync<List<string>>("api/taxcalculations/getpostalcodes");
                if (result is not null) PostalCodes = result;
                else PostalCodes = new List<string>();
            } 
            catch
            {
                PostalCodes = new List<string>();
            }
		}

        #region Helpers

        private async void SetTaxCalculations(HttpResponseMessage response)
        {
            var result = await response.Content.ReadFromJsonAsync<List<TaxCalculation>>();
            TaxCalculations = result;
            _navigationManager.NavigateTo("taxcalculations");
        }

        #endregion


    }
}
