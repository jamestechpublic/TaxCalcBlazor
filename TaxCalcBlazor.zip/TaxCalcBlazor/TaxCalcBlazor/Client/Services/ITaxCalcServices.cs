﻿namespace TaxCalcBlazor.Client.Services
{
    public interface ITaxCalcServices
    {
        List<string> PostalCodes { get; set; }
        List<TaxCalculation> TaxCalculations { get; set; }

        Task GetAllTaxCalculationsAsync();
        Task<TaxCalculation> GetSingleTaxCalculationsAsync(int id);
        Task CreateTaxCalculationAsync(TaxCalculation taxCalculation);
        Task UpdateTaxCalculationAsync(TaxCalculation taxCalculation);
        Task DeleteTaxCalculationAsync(int id);
        Task<TaxCalculation> CalculateTaxAsync(TaxCalculation taxCalculation);
        Task GetPostalCodes();
    }
}
