namespace TaxCalcBlazor.Test.AppLogicTest
{
    public class TaxCalcTest
    {
        [Fact]
        public void TaxCalc_CalcFlatValue_MoreThan199999_is_10000()
        {
            // Arrange
            var taxCalc = new TaxCalc();
            decimal income = 200000m;
            decimal expectedTax = 10000m;

            // Act
            decimal result = taxCalc.CalcFlatValue(income);

            // Assert
            result.Should().Be(expectedTax);
        }

		[Fact]
		public void TaxCalc_CalcFlatValue_LessThan200000_5_Percent()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			decimal income = 10000m;
			decimal expectedTax = 500m;

			// Act
			decimal result = taxCalc.CalcFlatValue(income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcFlatRate_is_175_Percent()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			decimal income = 100000m;
			decimal expectedTax = 17500m;

			// Act
			decimal result = taxCalc.CalcFlatRate(income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcProgressive_TaxBracket_1_Ok()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			decimal income = 8350m;
			decimal expectedTax = 835m;

			// Act
			decimal result = taxCalc.CalcProgressive(income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcProgressive_TaxBracket_2_Ok()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			decimal income = 8351m;
			decimal expectedTax = 835.15m;

			// Act
			decimal result = taxCalc.CalcProgressive(income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcProgressive_TaxBracket_3_Ok()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			decimal income = 33951m;
			decimal expectedTax = 4675.25m;

			// Act
			decimal result = taxCalc.CalcProgressive(income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcProgressive_TaxBracket_4_Ok()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			decimal income = 82251m;
			decimal expectedTax = 16750.28m;

			// Act
			decimal result = taxCalc.CalcProgressive(income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcProgressive_TaxBracket_5_Ok()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			decimal income = 171551m;
			decimal expectedTax = 41754.33m;

			// Act
			decimal result = taxCalc.CalcProgressive(income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcProgressive_TaxBracket_6_Ok()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			decimal income = 372951m;
			decimal expectedTax = 108216.35m;

			// Act
			decimal result = taxCalc.CalcProgressive(income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcPostalCodeTax_7441_Must_Be_Progressive()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			string postalCode = "7441";
			decimal income = 372951m;
			decimal expectedTax = 108216.35m;

			// Act
			decimal result = taxCalc.CalcPostalCodeTax(postalCode, income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcPostalCodeTax_A001_Must_Be_FlatValue()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			string postalCode = "A001";
			decimal income = 200000m;
			decimal expectedTax = 10000m;

			// Act
			decimal result = taxCalc.CalcPostalCodeTax(postalCode, income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcPostalCodeTax_7000_Must_Be_FlatRate()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			string postalCode = "7000";
			decimal income = 100000m;
			decimal expectedTax = 17500m;

			// Act
			decimal result = taxCalc.CalcPostalCodeTax(postalCode, income);

			// Assert
			result.Should().Be(expectedTax);
		}

		[Fact]
		public void TaxCalc_CalcPostalCodeTax_1000_Must_Be_Progressive()
		{
			// Arrange
			var taxCalc = new TaxCalc();
			string postalCode = "1000";
			decimal income = 372951m;
			decimal expectedTax = 108216.35m;

			// Act
			decimal result = taxCalc.CalcPostalCodeTax(postalCode, income);

			// Assert
			result.Should().Be(expectedTax);
		}
	}
}