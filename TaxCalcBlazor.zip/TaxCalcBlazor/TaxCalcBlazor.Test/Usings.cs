global using Xunit;
global using FluentAssertions;
global using TaxCalcBlazor.Server.AppLogic;